#!/system/bin/sh
while [[ -z $(getprop sys.boot_completed) ]]; do sleep 45; done
echo "-11" > /proc/eem/EEM_DET_B/eem_offset
echo "-11" > /proc/eem/EEM_DET_BL/eem_offset
echo "-11" > /proc/eem/EEM_DET_L/eem_offset
echo "-7" > /proc/eem/EEM_DET_CCI/eem_offset
echo "-2" > /proc/eemg/EEMG_DET_GPU/eemg_offset
echo "-2" > proc/eemg/EEMG_DET_GPU_HI/eemg_offset